package cyz.ink.portfolio.service.excel;

import java.text.ParseException;
import java.io.File;

public class DateParseTest {
    public static void main(String[] args) throws ParseException {

       /** File f=new File("/Users/Zhangxian/Desktop/Java/Portfolio/src/main/resources/excel/ZROZ-PIMCO 25+ Year Zero Coupon U.S. Treasury Index Exchange-Traded Fund.xls");
        String fileName=f.getName();
        String prefix=fileName.substring(fileName.lastIndexOf("."));
        String prefix1=fileName.substring(fileName.indexOf("-"));
        int num=prefix.length();
        int num1=prefix1.length();
        String symbol=fileName.substring(0, fileName.length()-num1);
        int num2=symbol.length();
        String name=fileName.substring(num2+1,fileName.length()-num);



        System.out.println(name);*/


    }
}
